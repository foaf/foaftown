#!/bin/sh
ant -Dfoaftown.role=server -Dfoaftown.pwd=$P -Dfoaftown.my_jid=danbri@livejournal.com
