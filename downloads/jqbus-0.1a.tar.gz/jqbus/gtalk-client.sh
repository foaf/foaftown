#!/bin/sh
ant -Dfoaftown.role=client -Dfoaftown.pwd=$P -Dfoaftown.my_jid=danbrickley@gmail.com -Dfoaftown.other_jid=danbri@livejournal.com

