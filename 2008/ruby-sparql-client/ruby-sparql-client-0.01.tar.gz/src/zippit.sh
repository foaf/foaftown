#!/bin/sh

cd ..; tar -cvf  ruby-sparql-client-0.01.tar.gz src
